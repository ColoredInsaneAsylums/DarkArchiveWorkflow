from distutils.core import setup

setup(name='metadatautilspkg',
      version='0.1',
      description='Metadata utilities for archiving digital objects',
      author='Nitin Verma',
      author_email='nitin.verma@utexas.edu',
      url='https://wikis.utexas.edu/display/CSHProject/CSHProject+Home',
      packages=['metadatautilspkg'],
     )
